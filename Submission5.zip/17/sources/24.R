print(
	prop.test(c(44,70),c(259,258),
	conf.level=0.95,
	correct=FALSE,alt="greater")
$conf)